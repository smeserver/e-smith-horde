CREATE DATABASE IF NOT EXISTS horde;

CONNECT horde;

CREATE TABLE IF NOT EXISTS horde_users (
    user_uid       varchar(255) not null,
    user_pass      varchar(32) not null,
    primary key (user_uid)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON horde_users TO horde@localhost;

CREATE TABLE IF NOT EXISTS horde_prefs (
    pref_uid        char(255) not null,
    pref_scope      char(16) not null default '',
    pref_name       char(32) not null,
    pref_value      text null,
    primary key (pref_uid, pref_scope, pref_name)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON horde_prefs TO horde@localhost;

CREATE TABLE IF NOT EXISTS horde_categories (
       category_id INT not null,
       group_uid VARCHAR(255) not null,
       user_uid VARCHAR(255),
       category_name VARCHAR(255) not null,
       category_data TEXT null,
       category_serialized SMALLINT DEFAULT 0 not null,
       category_updated TIMESTAMP,
       PRIMARY KEY (category_id)
);

CREATE TABLE IF NOT EXISTS horde_categories_categories (
       category_id_parent INT not null,
       category_id_child INT not null,
       PRIMARY KEY (category_id_parent, category_id_child)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON horde_categories TO horde@localhost;
GRANT SELECT, INSERT, UPDATE, DELETE ON horde_categories_categories TO horde@localhost;

FLUSH PRIVILEGES;

