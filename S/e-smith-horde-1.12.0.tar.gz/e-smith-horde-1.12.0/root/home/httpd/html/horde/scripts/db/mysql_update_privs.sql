CONNECT mysql;

REPLACE INTO db (host, db, user, select_priv, insert_priv, update_priv,
                 delete_priv, create_priv, drop_priv, alter_priv, index_priv,
                 references_priv)
    VALUES (
        'localhost',
        'horde',
        'horde',
        'Y', 'Y', 'Y', 'Y',
        'Y', 'Y', 'Y', 'Y',
        'Y'
    );

FLUSH PRIVILEGES;

