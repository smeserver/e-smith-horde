CONNECT mysql;

DELETE FROM user WHERE user = 'horde' and host = '%';
DELETE FROM tables_priv WHERE user = 'horde' and host = '%';

FLUSH PRIVILEGES;
