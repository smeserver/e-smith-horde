CONNECT mysql;

REPLACE INTO user (host, user, password)
    VALUES (
        'localhost',
        'horde',
        password('{$horde{DbPassword}}')
    );

FLUSH PRIVILEGES;
